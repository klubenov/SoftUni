﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2King_sGambit.Contracts
{
    public interface ICharacter
    {
        string Name { get; }
    }
}
