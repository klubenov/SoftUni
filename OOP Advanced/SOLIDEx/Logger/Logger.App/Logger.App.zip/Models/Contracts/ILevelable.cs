﻿namespace Logger.App.Models.Contracts
{
    public interface ILevelable
    {
        ErrorLevel Level { get; }
    }
}
