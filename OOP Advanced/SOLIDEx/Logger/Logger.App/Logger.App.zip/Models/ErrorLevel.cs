﻿namespace Logger.App.Models
{
    public enum ErrorLevel
    {
        INFO, WARNING, ERROR, CRITICAL, FATAL
    }
}
