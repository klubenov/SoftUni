﻿public class Program
{
    public static void Main(string[] args)
    {
        IEnergyRepository energyRepository = new EnergyRepository();
        IHarvesterController harvesterController = new HarvesterController(energyRepository);
        IProviderController providerController = new ProviderController(energyRepository);
        ICommandInterpreter commandInterpreter = new CommandInterpreter(providerController,harvesterController);

        Engine engine = new Engine(providerController, harvesterController, commandInterpreter);
        engine.Run();
    }
}