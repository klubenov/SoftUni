﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Engine
{
    private DraftManager manager;
    private ICommandInterpreter commandInterpreter;

    public Engine(IProviderController providerController, IHarvesterController harvesterController, ICommandInterpreter commandInterpreter)
    {
        this.manager = new DraftManager(providerController, harvesterController);
        this.commandInterpreter = commandInterpreter;
    }

    public void Run()
    {
        while (true)
        {
            var input = Console.ReadLine();
            var data = input.Split().ToList();
            Console.WriteLine(commandInterpreter.ProcessCommand(data));
            if (input=="Shutdown")
            {
                Environment.Exit(0);
            }
        }
    }
}
