﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=DESKTOP-R2VVJJ2\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}