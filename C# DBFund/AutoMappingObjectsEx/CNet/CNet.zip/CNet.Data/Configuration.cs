﻿namespace CNet.Data
{
    public class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-AE56UDL\SQLEXPRESS;Database=CNet;Integrated Security=True";
    }
}
