﻿namespace CNet.Services.Contracts
{
    public interface IDbInitializerService
    {
        void InitializeDatabase();
    }
}
