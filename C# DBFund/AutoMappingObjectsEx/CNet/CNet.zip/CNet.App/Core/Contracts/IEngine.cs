﻿namespace CNet.App.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
