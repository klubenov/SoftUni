﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_BillsPaymentSystem.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-AE56UDL\SQLEXPRESS;Database=PaymentSystem;Integrated Security=True";
    }
}
