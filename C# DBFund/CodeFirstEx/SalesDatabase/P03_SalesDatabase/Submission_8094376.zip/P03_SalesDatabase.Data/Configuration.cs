﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    internal class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-AE56UDL\SQLEXPRESS;Database=Sales;Integrated Security=True";
    }
}
