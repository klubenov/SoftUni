﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P011InitialSetup
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-AE56UDL\SQLEXPRESS;Database=MinionsDB;Integrated Security=True";
    }
}
