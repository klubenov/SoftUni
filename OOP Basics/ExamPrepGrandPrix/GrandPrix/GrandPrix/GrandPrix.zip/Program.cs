﻿using System;
using System.Linq;


class Program
{
    static void Main(string[] args)
    {
        
    }
}

