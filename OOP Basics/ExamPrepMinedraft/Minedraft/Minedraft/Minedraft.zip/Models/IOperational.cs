﻿using System;
using System.Collections.Generic;
using System.Text;


public interface IOperational
{
    string Id { get; }

    string Type { get; }
}

