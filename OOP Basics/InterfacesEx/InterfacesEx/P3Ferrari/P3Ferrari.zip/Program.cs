﻿using System;


class Program
{
    static void Main(string[] args)
    {
        var ferrari = new Ferrari(Console.ReadLine());
        Console.WriteLine(ferrari);
    }
}

