﻿using System;
using System.IO;
using SIS.Framework;
using SIS.Framework.Routers;
using SIS.WebServer;

namespace SIS.MVCDemo
{
    public class Launcher
    {
        public static void Main(string[] args)
        {
            var server = new Server(8000, new ControllerRouter());

            MvcEngine.Run(server);
        }
    }
}
