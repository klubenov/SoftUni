﻿namespace SIS.Framework.ActionResults.Base
{
    public interface IActionResult
    {
        string Invoke();
    }
}
