﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exam.App.ViewModels
{
    public class DeliverPackageViewModel
    {
        public string Description { get; set; }

        public int Id { get; set; }
    }
}
