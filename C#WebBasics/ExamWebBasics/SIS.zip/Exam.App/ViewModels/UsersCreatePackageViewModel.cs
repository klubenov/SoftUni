﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exam.App.ViewModels
{
    public class UsersCreatePackageViewModel
    {
        public string Username { get; set; }
    }
}
