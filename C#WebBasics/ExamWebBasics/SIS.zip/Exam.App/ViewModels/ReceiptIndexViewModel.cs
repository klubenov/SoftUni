﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exam.App.ViewModels
{
    public class ReceiptIndexViewModel
    {
        public string Id { get; set; }

        public string Fee { get; set; }

        public string IssuedOn { get; set; }

        public string Recipient { get; set; }
    }
}
