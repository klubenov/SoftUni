﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exam.Models.Enums
{
    public enum Role
    {
        User,
        Admin
    }
}
