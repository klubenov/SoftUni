﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exam.Models.Enums
{
    public enum Status
    {
        Pending,
        Shipped,
        Delivered,
        Acquired
    }
}
