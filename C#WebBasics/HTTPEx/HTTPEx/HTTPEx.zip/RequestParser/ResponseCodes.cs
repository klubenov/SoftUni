﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RequestParser
{
    public enum ResponseCodes
    {
        OK = 200,
        NotFound = 404
    }
}
