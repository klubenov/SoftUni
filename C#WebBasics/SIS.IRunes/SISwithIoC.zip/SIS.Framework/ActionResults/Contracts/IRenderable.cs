﻿namespace SIS.Framework.ActionResults.Contracts
{
    public interface IRenderable
    {
        string Render();
    }
}
